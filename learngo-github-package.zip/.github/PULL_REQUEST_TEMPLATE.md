### 📝 Beschreibung

Bitte beschreibe, was dieser Pull Request verändert oder behebt.

---

### ✅ Checkliste

- [ ] Funktion wurde lokal getestet
- [ ] Keine sensiblen Daten enthalten
- [ ] Feature ist dokumentiert (README, Kommentare)
- [ ] Branch folgt dem Schema `feature/xyz`

---

### 📸 Screenshots (optional)

Füge Screenshots hinzu, falls UI betroffen ist.

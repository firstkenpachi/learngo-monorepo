# 📚 LearnGo Monorepo

Smartes, KI-gestütztes Lernsystem mit Web-Frontend, API-Backend, Mobile-App (Expo) und Desktop-App (Electron).

## 🚀 Deploy-Status

![Vercel](https://img.shields.io/badge/frontend-Vercel-blue)
![Render](https://img.shields.io/badge/backend-Render-green)
![Expo](https://img.shields.io/badge/mobile-Expo-orange)

---

## 📁 Projektstruktur

```
learngo-monorepo/
├── client/      → React (Vite) Web App
├── server/      → Express API mit OpenAI + LanguageTool
├── mobile/      → React Native (Expo)
├── desktop/     → Electron App (für lokale Nutzung)
```

---

## 🔧 .env Konfiguration (server/.env)

```env
OPENAI_API_KEY=your_openai_api_key_here
```

---

## ▶️ Schnellstart

### Web-Client
```bash
cd client
npm install
npm run dev
```

### Backend-Server
```bash
cd server
cp .env.example .env
npm install
node index.js
```

### Mobile (Expo)
```bash
cd mobile
npm install
npx expo start
```

### Electron-Desktop
```bash
cd client
npm run electron
```

---

## 📦 Deployment-Empfehlung

| Komponente | Plattform | Tool        |
|------------|-----------|-------------|
| Frontend   | Vercel    | `/client`   |
| Backend    | Render    | `/server`   |
| Mobile     | Expo Go   | `/mobile`   |

---

## 🤝 Mitwirken

Bevor du einen Pull Request öffnest:

- Nutze einen Branch (`feature/dein-feature`)
- Füge eine Beschreibung hinzu
- Achte auf sauberen Commit-Log

---

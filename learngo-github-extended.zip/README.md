# 📚 LearnGo Monorepo

Smartes, KI-gestütztes Lernsystem mit Web, Mobile und Desktop-Komponenten.  
Lerne, analysiere und teste Inhalte mit OCR, GPT und adaptivem Feedback.

---

## 🌐 Live Links

- 🖥️ Web Frontend (Vercel): [https://learngo.vercel.app](#)
- 🧠 API Backend (Render): [https://learngo-api.onrender.com](#)
- 📱 Mobile App (Expo): [https://expo.dev/@youruser/learngo](#)

---

## 🚀 Deploy-Status

![Vercel](https://img.shields.io/badge/frontend-Vercel-blue)
![Render](https://img.shields.io/badge/backend-Render-green)
![Expo](https://img.shields.io/badge/mobile-Expo-orange)

---

## 📁 Projektstruktur

```
learngo-monorepo/
├── client/      → React Web App
├── server/      → Express API mit GPT-4 & LanguageTool
├── mobile/      → React Native App (Expo)
├── desktop/     → Electron Wrapper
```

---

## 🔧 Konfiguration (.env Beispiel)

In `server/.env`:
```env
OPENAI_API_KEY=your_key
PORT=3001
NODE_ENV=development
```

---

## 🏁 Schnellstart

### Web (Vite)
```bash
cd client
npm install
npm run dev
```

### Server (Node.js)
```bash
cd server
cp .env.example .env
npm install
node index.js
```

### Mobile (Expo)
```bash
cd mobile
npm install
npx expo start
```

### Desktop (Electron)
```bash
cd client
npm run electron
```

---

## ✅ Branchstrategie

- `main` → stabile Version
- `dev` → Entwicklung
- `feature/*` → neue Features
- `fix/*` → Bugfixes

Beispiel:
```bash
git checkout -b feature/ocr-upload
```

---

## 🤝 Mitwirken

Bitte verwende Pull Requests von `feature/*` → `dev`  
Nutze die Vorlage aus `.github/PULL_REQUEST_TEMPLATE.md`

---
